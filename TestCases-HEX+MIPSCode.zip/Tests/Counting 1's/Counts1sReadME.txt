Count Number of 1's in a Value

1- Load the desired number you want to count the 1's in register $1.
2- The program will do 15 loops to check the number of 1's in the register 
3- the program will store the number of 1's in register $3

