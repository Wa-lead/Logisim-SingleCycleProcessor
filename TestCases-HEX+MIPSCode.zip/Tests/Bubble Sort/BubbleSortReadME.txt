BubbleSort Read Me:

1- Initilaize all the values you're willing to sort in the first 4 insturction ( registers $1, $2, $3, and $4)

ori $1, $0, value 1
ori $2, $0, value 2
ori $3, $0, value 3
ori $4, $0, value 4

2- set the upper limit ( number of values - 1 ) and store it in $6

3- in instruction 38: decrement the array by the number of elements

4- to check the sorted array, check the Data Memory.